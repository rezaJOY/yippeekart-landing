
import React from 'react';
import { Link } from 'react-router-dom';
import { PAGES } from '../constants';
import { useLanguage } from '../LanguageContext';
import SEO from '../components/SEO';
import LanguageBlock from '../components/LanguageBlock';
import { SectionWrapper, ContentRenderer } from '../components/Sections';

/**
 * PageTemplate dynamically renders page content based on the constants registry.
 */
const PageTemplate: React.FC<{ pageKey: string }> = ({ pageKey }) => {
  const content = PAGES[pageKey];
  const { language } = useLanguage();
  
  if (!content) return <div className="p-20 text-center">Page not found</div>;

  return (
    <>
      <SEO data={content.seo} />
      
      {/* Hero Section */}
      {content.hero && (
        <SectionWrapper variant="navy" slant="bottom">
          <div className={`text-center ${language === 'ar' ? 'md:text-right' : 'md:text-left'}`}>
            <h1 className={`text-3xl sm:text-5xl md:text-6xl lg:text-8xl font-black tracking-tighter mb-8 leading-[0.9] ${language === 'ar' ? 'lang-ar' : language === 'bn' ? 'lang-bn' : ''}`}>
              {content.hero.title[language]}
            </h1>
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              <div className="max-w-2xl">
                <LanguageBlock content={content.hero.subtitle} className="!text-white/90 !text-lg md:!text-2xl font-medium leading-relaxed" />
                <div className="mt-10 flex flex-wrap gap-4 justify-center md:justify-start">
                  <Link 
                    to="/contact"
                    className="px-8 py-4 bg-[#76bc21] text-[#00334e] font-bold uppercase tracking-widest text-xs rounded-full hover:bg-white transition-all shadow-lg shadow-[#76bc21]/20 active:scale-95 inline-block"
                  >
                    {language === 'ar' ? 'تواصل معنا' : language === 'bn' ? 'যোগাযোগ করুন' : 'Get in Touch'}
                  </Link>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 lg:pt-0">
                {content.hero.stats.map((stat, i) => (
                  <div key={i} className="bg-white/5 border border-white/10 p-6 backdrop-blur-md rounded-2xl hover:bg-white/10 transition-colors">
                    <div className="text-4xl font-black mb-1 text-[#76bc21]">{stat.value}</div>
                    <div className={`text-[10px] uppercase tracking-widest text-white/50 font-bold ${language === 'ar' ? 'lang-ar text-xs' : language === 'bn' ? 'lang-bn text-xs' : ''}`}>
                      {stat.label[language]}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </SectionWrapper>
      )}

      {/* Content Sections Mapping */}
      {content.sections.map((section, idx) => (
        <SectionWrapper 
          key={section.id} 
          variant={idx % 2 === 0 ? 'white' : 'grey'}
          id={section.id}
        >
          <div className="mb-12 md:mb-20">
            <LanguageBlock content={section.heading} isHeading={true} className="border-b-4 border-[#76bc21] pb-4 inline-block" />
          </div>
          <div className="max-w-4xl">
            <ContentRenderer section={section} />
          </div>
        </SectionWrapper>
      ))}
    </>
  );
};

export default PageTemplate;
