
import React from 'react';
import { useLanguage } from '../LanguageContext';
import { Language } from '../types';

const LanguageSwitcher: React.FC = () => {
  const { language, setLanguage } = useLanguage();
  const options: { code: Language; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'ar', label: 'العربية' },
    { code: 'bn', label: 'বাংলা' }
  ];

  return (
    <div className="flex items-center bg-slate-100/50 rounded-full p-1 border border-slate-200 backdrop-blur-sm">
      {options.map((opt) => (
        <button
          key={opt.code}
          onClick={() => setLanguage(opt.code)}
          className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[9px] sm:text-[10px] font-bold uppercase tracking-wider transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${
            language === opt.code 
            ? 'bg-slate-900 text-white shadow-md transform scale-105' 
            : 'text-slate-500 hover:text-slate-900 hover:bg-white/50'
          } ${opt.code === 'ar' ? 'lang-ar' : opt.code === 'bn' ? 'lang-bn' : ''}`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
};

export default LanguageSwitcher;
