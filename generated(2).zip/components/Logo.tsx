
import React from 'react';
import { useLanguage } from '../LanguageContext';

interface LogoProps {
  light?: boolean;
  className?: string;
}

/**
 * The Corporate Logo component.
 * Features an SVG reconstruction of the brand identity.
 * Fixed: Added better text scaling for long Arabic/Bengali strings.
 */
export const Logo: React.FC<LogoProps> = ({ light = false, className = "" }) => {
  const { language } = useLanguage();
  
  const brandNames = {
    en: "Ripon Enterprise",
    ar: "مؤسسة ريبون",
    bn: "রিপন এন্টারপ্রাইজ"
  };

  const mainColor = light ? "#ffffff" : "#00334e";
  const accentColor = "#76bc21";
  const textColor = light ? "text-white" : "text-[#00334e]";
  const subtextColor = light ? "text-white/60" : "text-slate-500";

  return (
    <div className={`flex items-center gap-2 sm:gap-4 group max-w-full min-w-0 ${className}`}>
      <div className="relative w-8 h-8 sm:w-12 sm:h-12 md:w-14 md:h-14 flex items-center justify-center flex-shrink-0">
        <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-sm transition-transform group-hover:scale-105 duration-500">
          <path 
            d="M50 140C30 120 20 90 25 60C35 25 75 10 110 20C140 30 165 60 170 95C175 130 155 165 125 180L100 170M50 140C60 155 80 175 110 175C140 175 165 155 175 130" 
            stroke={mainColor} 
            strokeWidth="12" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
          />
          <path d="M45 135L35 125M50 145L40 135M55 155L45 145M60 165L50 155" stroke={mainColor} strokeWidth="8" strokeLinecap="round" />
          <path 
            d="M60 85L85 82L105 55L115 54L105 80L155 75C165 74 175 78 178 85C181 92 178 100 165 102L115 108L120 125L110 127L100 110L75 114C65 116 60 112 60 105L60 85Z" 
            fill={accentColor} 
          />
        </svg>
      </div>
      <div className="flex flex-col ltr:text-left rtl:text-right select-none min-w-0 overflow-hidden">
        <span className={`text-[12px] xs:text-[14px] sm:text-lg md:text-xl lg:text-2xl font-black tracking-tight ${textColor} leading-tight truncate ${language !== 'en' ? (language === 'ar' ? 'lang-ar' : 'lang-bn') : ''}`}>
          {brandNames[language]}
        </span>
        <span className={`text-[5px] xs:text-[7px] sm:text-[8px] md:text-[9px] font-bold ${subtextColor} tracking-tight sm:tracking-[0.25em] uppercase mt-0.5 whitespace-nowrap overflow-hidden text-ellipsis ${language === 'ar' ? 'lang-ar text-[7px] sm:text-[10px]' : ''}`}>
          {language === 'ar' ? 'ترخيص حكومي رقم RL-XXXX' : language === 'bn' ? 'সরকারি লাইসেন্স নং RL-XXXX' : 'Govt. Licensed Agency RL-XXXX'}
        </span>
      </div>
    </div>
  );
};
