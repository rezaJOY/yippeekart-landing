
import React from 'react';
import { UI_LABELS } from '../constants';
import { useLanguage } from '../LanguageContext';
// Fixed import: Logo is exported from ./Logo, not ./Navigation
import { Logo } from './Logo';

const Footer: React.FC = () => {
  const { language } = useLanguage();

  return (
    <footer className="bg-[#001a2c] text-white pt-20 pb-10 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
        <div className="space-y-6 ltr:text-left rtl:text-right">
          <Logo light />
          <p className={`text-slate-400 text-sm leading-relaxed max-w-sm mt-6 ${language === 'ar' ? 'lang-ar' : language === 'bn' ? 'lang-bn' : ''}`}>
            {UI_LABELS.footer_desc[language]}
          </p>
          <div className="inline-flex items-center px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-[10px] uppercase font-bold tracking-widest text-[#76bc21]">
            <span className="w-2 h-2 rounded-full bg-[#76bc21] ltr:mr-3 rtl:ml-3 animate-pulse"></span>
            License No: RL-XXXX
          </div>
        </div>
        
        <div className="space-y-6 ltr:text-left rtl:text-right">
          <h4 className={`text-xs font-bold uppercase tracking-widest text-slate-500 border-b border-white/5 pb-3 ${language === 'ar' ? 'lang-ar text-sm' : language === 'bn' ? 'lang-bn text-sm' : ''}`}>
            {UI_LABELS.compliance_title[language]}
          </h4>
          <ul className={`text-slate-400 text-sm space-y-4 ${language === 'ar' ? 'lang-ar' : language === 'bn' ? 'lang-bn' : ''}`}>
            <li className="flex items-start group cursor-default">
              <span className="ltr:mr-3 rtl:ml-3 text-[#76bc21]">✓</span> 
              <span className="group-hover:text-white transition-colors">BMET Emigration Act Compliance</span>
            </li>
            <li className="flex items-start group cursor-default">
              <span className="ltr:mr-3 rtl:ml-3 text-[#76bc21]">✓</span> 
              <span className="group-hover:text-white transition-colors">Saudi MOFA & Musaned Integration</span>
            </li>
            <li className="flex items-start group cursor-default">
              <span className="ltr:mr-3 rtl:ml-3 text-[#76bc21]">✓</span> 
              <span className="group-hover:text-white transition-colors">GAMCA Approved Medical Screening</span>
            </li>
            <li className="flex items-start group cursor-default">
              <span className="ltr:mr-3 rtl:ml-3 text-[#76bc21]">✓</span> 
              <span className="group-hover:text-white transition-colors">Zero Recruitment Fee Policy</span>
            </li>
          </ul>
        </div>

        <div className="space-y-6 ltr:text-left rtl:text-right">
          <h4 className={`text-xs font-bold uppercase tracking-widest text-slate-500 border-b border-white/5 pb-3 ${language === 'ar' ? 'lang-ar text-sm' : language === 'bn' ? 'lang-bn text-sm' : ''}`}>
            {UI_LABELS.contact_title[language]}
          </h4>
          <div className={`text-slate-400 text-sm space-y-5 ${language === 'ar' ? 'lang-ar' : language === 'bn' ? 'lang-bn' : ''}`}>
            <div className="flex items-start">
              <span className="w-5 h-5 ltr:mr-3 rtl:ml-3 mt-0.5 flex-shrink-0 text-slate-600">📍</span>
              <div>
                <p className="font-bold text-white">Dhaka Head Office</p>
                <p className="text-slate-500">People's Republic of Bangladesh</p>
              </div>
            </div>
            <div className="space-y-4">
              <a href="mailto:corporate@riponenterprise.com" className="flex items-center group">
                <span className="w-5 h-5 ltr:mr-3 rtl:ml-3 flex-shrink-0 text-slate-600">✉</span>
                <span className="group-hover:text-[#76bc21] transition-colors">corporate@riponenterprise.com</span>
              </a>
              <div className="flex items-center group">
                <span className="w-5 h-5 ltr:mr-3 rtl:ml-3 flex-shrink-0 text-slate-600">💬</span>
                <span className="group-hover:text-white transition-colors">WhatsApp: +880-XXXXXXXXXX</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6 text-[10px] uppercase font-bold tracking-widest text-slate-600 text-center">
        <div className={language === 'ar' ? 'lang-ar' : language === 'bn' ? 'lang-bn' : ''}>
          © {new Date().getFullYear()} Ripon Enterprise. {UI_LABELS.rights_reserved[language]}.
        </div>
        <div className="flex items-center space-x-6">
          <span className="hover:text-white transition-colors">Bangladesh</span>
          <span className="w-1 h-1 rounded-full bg-slate-800"></span>
          <span className="hover:text-white transition-colors">Saudi Arabia</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
