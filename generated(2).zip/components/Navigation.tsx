
import React, { useState, useEffect } from 'react';
// Re-importing from react-router-dom with standard named exports
import { Link, NavLink, useLocation } from 'react-router-dom';
import { NAV_LINKS } from '../constants';
import { useLanguage } from '../LanguageContext';
import LanguageSwitcher from './LanguageSwitcher';
import { Logo } from './Logo';

const Navigation: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { pathname } = useLocation();
  const { language } = useLanguage();

  // Close mobile drawer on route change
  useEffect(() => setIsOpen(false), [pathname]);

  return (
    <header className="fixed top-0 w-full z-[100] bg-white border-b border-slate-200 h-16 sm:h-24 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between gap-2">
        <Link 
          to="/" 
          className="flex items-center hover:opacity-90 active:scale-[0.98] transition-all relative z-[110] min-w-0"
        >
          <Logo />
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center h-full flex-shrink-0">
          <nav className="flex items-center space-x-1 ltr:mr-8 rtl:ml-8">
            {NAV_LINKS.map((link) => (
              <NavLink 
                key={link.path}
                to={link.path}
                end={link.path === '/'}
                className={({ isActive }) => `px-3 xl:px-4 py-2 rounded-md text-[10px] xl:text-[11px] font-black uppercase tracking-widest transition-all duration-200 ${
                  isActive 
                    ? 'bg-[#00334e] text-white shadow-lg shadow-[#00334e]/10' 
                    : 'text-slate-500 hover:text-[#00334e] hover:bg-slate-50'
                } ${language === 'ar' ? 'lang-ar text-sm' : language === 'bn' ? 'lang-bn text-sm' : ''}`}
              >
                {link.name[language]}
              </NavLink>
            ))}
          </nav>
          <div className="ltr:border-l rtl:border-r border-slate-200 ltr:pl-8 rtl:pr-8 h-8 flex items-center">
            <LanguageSwitcher />
          </div>
        </div>

        {/* Mobile Controls */}
        <div className="flex lg:hidden items-center gap-1.5 sm:gap-3 relative z-[210] flex-shrink-0">
          <div className="scale-[0.7] sm:scale-90 origin-right">
            <LanguageSwitcher />
          </div>
          <button 
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="p-1.5 sm:p-3 rounded-lg sm:rounded-xl bg-slate-50 text-[#00334e] hover:bg-slate-100 transition-colors border border-slate-200 shadow-sm"
            aria-label="Toggle Navigation"
          >
            <svg className="w-5 h-5 sm:w-6 sm:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
              {isOpen ? <path d="M6 18L18 6M6 6l12 12" /> : <path d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      <div 
        className={`lg:hidden fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity duration-300 z-[180] ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsOpen(false)}
      />
      <div 
        className={`lg:hidden fixed top-0 ltr:right-0 rtl:left-0 w-[85%] max-w-sm h-full bg-white shadow-2xl z-[190] transform transition-transform duration-500 ease-in-out ${isOpen ? 'translate-x-0' : 'ltr:translate-x-full rtl:-translate-x-full'}`}
      >
        <div className="flex flex-col h-full pt-20 sm:pt-28 px-6 pb-10 overflow-y-auto">
          <div className="flex flex-col space-y-3">
            {NAV_LINKS.map((link) => (
              <NavLink 
                key={link.path}
                to={link.path}
                end={link.path === '/'}
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => `flex items-center px-6 py-4 sm:py-5 rounded-xl text-[11px] sm:text-[12px] font-black uppercase tracking-widest border transition-all ${
                  isActive 
                    ? 'bg-[#00334e] text-white border-[#00334e] shadow-xl' 
                    : 'bg-white text-slate-600 border-slate-100 hover:bg-slate-50 shadow-sm'
                } ${language === 'ar' ? 'lang-ar text-right text-sm' : language === 'bn' ? 'lang-bn text-left text-sm' : ''}`}
              >
                {link.name[language]}
              </NavLink>
            ))}
          </div>
          <div className="mt-auto pt-10 text-center border-t border-slate-50">
            <p className="text-[10px] font-black text-slate-400 tracking-[0.4em] uppercase">Ripon Enterprise</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navigation;
