
import React from 'react';
import { MultiLangText, Language } from '../types';
import { useLanguage } from '../LanguageContext';

/**
 * Utility to get language-specific font classes and sizes.
 */
export const getLangStyles = (lang: Language) => {
  switch (lang) {
    case 'ar': return 'lang-ar text-lg sm:text-xl md:text-2xl';
    case 'bn': return 'lang-bn text-base sm:text-lg md:text-xl';
    default: return 'font-sans text-base sm:text-lg';
  }
};

interface LanguageBlockProps {
  content: MultiLangText;
  isHeading?: boolean;
  className?: string;
}

/**
 * LanguageBlock renders text in the currently selected language 
 * with appropriate typography settings.
 */
const LanguageBlock: React.FC<LanguageBlockProps> = ({ content, isHeading = false, className = "" }) => {
  const { language } = useLanguage();
  const langClass = getLangStyles(language);
  const text = content[language];

  if (isHeading) {
    return (
      <h2 className={`font-bold text-slate-900 uppercase tracking-tight ${langClass} ${language === 'en' ? 'text-xl sm:text-2xl md:text-3xl' : ''} ${className}`}>
        {text}
      </h2>
    );
  }

  return (
    <p className={`text-slate-700 leading-relaxed ${langClass} ${className}`}>
      {text}
    </p>
  );
};

export default LanguageBlock;
