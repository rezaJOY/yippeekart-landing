
import React, { useEffect } from 'react';
import { SEOData } from '../types';

/**
 * SEO Component handles dynamic metadata updates for SPA navigation.
 * It ensures the document title and description reflect the current page state.
 */
const SEO: React.FC<{ data: SEOData }> = ({ data }) => {
  useEffect(() => {
    document.title = data.title;
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', data.description);
    }

    const metaKeywords = document.querySelector('meta[name="keywords"]');
    if (metaKeywords) {
      metaKeywords.setAttribute('content', data.keywords.join(', '));
    }
  }, [data]);

  return null;
};

export default SEO;
