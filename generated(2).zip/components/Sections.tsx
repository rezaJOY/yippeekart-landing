
import React, { useState } from 'react';
import { SectionContent, MultiLangText } from '../types';
import LanguageBlock from './LanguageBlock';
import { useLanguage } from '../LanguageContext';
import { UI_LABELS } from '../constants';

interface SectionWrapperProps {
  children: React.ReactNode;
  variant?: 'white' | 'grey' | 'navy';
  slant?: 'none' | 'top' | 'bottom' | 'both';
  id?: string;
}

export const SectionWrapper: React.FC<SectionWrapperProps> = ({ 
  children, 
  variant = 'white', 
  slant = 'none',
  id 
}) => {
  const bgClasses = {
    white: 'bg-white text-slate-900',
    grey: 'bg-slate-50 text-slate-900',
    navy: 'bg-[#001a2c] text-white'
  };

  const slantClasses = {
    none: 'py-16 md:py-24',
    top: 'slanted-top -mt-16 md:-mt-24 pt-32 md:pt-48 pb-16 md:pb-24',
    bottom: 'slanted-bottom pt-16 md:pt-24 pb-32 md:pb-48',
    both: 'slanted-both -mt-16 md:-mt-24 pt-32 md:pt-48 pb-32 md:pb-48'
  };

  return (
    <section 
      id={id}
      className={`relative px-4 sm:px-6 md:px-12 overflow-hidden transition-colors duration-500 ${bgClasses[variant]} ${slantClasses[slant]}`}
    >
      <div className="max-w-5xl mx-auto relative z-10">
        {children}
      </div>
    </section>
  );
};

const FAQ: React.FC<{ faqs: any[] }> = ({ faqs }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const { language } = useLanguage();

  return (
    <div className="space-y-4">
      {faqs.map((faq, idx) => (
        <div key={idx} className={`border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-sm transition-all duration-300 ${openIndex === idx ? 'ring-2 ring-[#76bc21]/30 border-[#76bc21]' : 'hover:border-slate-300'}`}>
          <button 
            onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            className="w-full flex items-center justify-between p-5 md:p-7 text-left focus:outline-none transition-colors group"
            aria-expanded={openIndex === idx}
          >
            <LanguageBlock content={faq.question} className={`!text-slate-900 font-bold transition-colors ${openIndex === idx ? '!text-[#00334e]' : 'group-hover:text-[#00334e]'}`} />
            <span className={`flex-shrink-0 ml-4 w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center transition-all duration-300 ${openIndex === idx ? 'rotate-180 bg-[#76bc21] text-white' : 'text-slate-400 group-hover:bg-slate-100'}`}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7" /></svg>
            </span>
          </button>
          <div 
            className={`transition-all duration-500 ease-in-out overflow-hidden ${openIndex === idx ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'}`}
          >
            <div className="px-7 pb-7">
              <LanguageBlock content={faq.answer} className="text-slate-600 border-t border-slate-100 pt-5 leading-relaxed" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

const ContactForm: React.FC = () => {
  const { language } = useLanguage();
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('submitting');
    
    const formData = new FormData(e.currentTarget);

    try {
      // Standard Formspree submission using standard headers for reliability
      const response = await fetch('https://formspree.io/f/reza.joy.work@gmail.com', {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json'
        }
      });

      if (response.ok) {
        setStatus('success');
      } else {
        setStatus('error');
      }
    } catch (err) {
      setStatus('error');
    }
  };

  if (status === 'success') {
    return (
      <div className="bg-emerald-50 border border-emerald-100 p-10 rounded-3xl text-center shadow-inner">
        <div className="w-16 h-16 bg-emerald-500 text-white rounded-full flex items-center justify-center text-3xl mx-auto mb-6 shadow-lg">✓</div>
        <LanguageBlock content={UI_LABELS.form_success} className="text-emerald-900 font-black text-xl mb-2" />
        <p className="text-emerald-700/70 text-sm mb-6">Our team will contact you shortly.</p>
        <button 
          onClick={() => setStatus('idle')}
          className="px-6 py-3 bg-emerald-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-emerald-700 transition-colors"
        >
          {language === 'ar' ? 'إرسال رسالة أخرى' : language === 'bn' ? 'আরেকটি বার্তা পাঠান' : 'Send Another Message'}
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 md:p-12 rounded-[2.5rem] shadow-2xl border border-slate-100 relative overflow-hidden group">
      <div className="absolute top-0 left-0 w-2 h-full bg-[#76bc21] opacity-0 group-focus-within:opacity-100 transition-opacity"></div>
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <label className="block text-[10px] uppercase font-black text-slate-400 mb-3 tracking-[0.2em] ml-1">
            {UI_LABELS.form_name[language]}
          </label>
          <input 
            required
            name="name"
            type="text" 
            className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-0 focus:border-[#76bc21] transition-all outline-none font-medium text-slate-900 placeholder-slate-300"
            placeholder="John Doe"
          />
        </div>
        <div>
          <label className="block text-[10px] uppercase font-black text-slate-400 mb-3 tracking-[0.2em] ml-1">
            {UI_LABELS.form_email[language]}
          </label>
          <input 
            required
            name="email"
            type="email" 
            className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-0 focus:border-[#76bc21] transition-all outline-none font-medium text-slate-900 placeholder-slate-300"
            placeholder="john@company.com"
          />
        </div>
      </div>
      <div>
        <label className="block text-[10px] uppercase font-black text-slate-400 mb-3 tracking-[0.2em] ml-1">
          {UI_LABELS.form_phone[language]}
        </label>
        <input 
          required
          name="phone"
          type="tel" 
          className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-0 focus:border-[#76bc21] transition-all outline-none font-medium text-slate-900 placeholder-slate-300"
          placeholder="+880..."
        />
      </div>
      <div>
        <label className="block text-[10px] uppercase font-black text-slate-400 mb-3 tracking-[0.2em] ml-1">
          {UI_LABELS.form_message[language]}
        </label>
        <textarea 
          required
          name="message"
          rows={5}
          className="w-full px-6 py-5 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:ring-0 focus:border-[#76bc21] transition-all outline-none font-medium text-slate-900 placeholder-slate-300 resize-none"
          placeholder="How can we help your organization?"
        ></textarea>
      </div>
      <button 
        disabled={status === 'submitting'}
        type="submit"
        className={`w-full py-6 bg-[#00334e] text-white font-black uppercase tracking-[0.3em] text-[11px] rounded-2xl shadow-xl shadow-[#00334e]/20 hover:bg-[#002235] hover:-translate-y-1 transition-all active:scale-[0.98] flex items-center justify-center gap-4 group ${status === 'submitting' ? 'opacity-70 cursor-not-allowed' : ''}`}
      >
        {status === 'submitting' ? (
          <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
        ) : (
          <>
            {UI_LABELS.form_submit[language]}
            <span className="text-lg transition-transform group-hover:translate-x-1 rtl:group-hover:-translate-x-1">→</span>
          </>
        )}
      </button>
      {status === 'error' && (
        <p className="text-red-500 text-xs text-center font-bold bg-red-50 py-3 rounded-xl border border-red-100 animate-bounce">
          {language === 'ar' ? 'حدث خطأ. حاول مرة أخرى.' : language === 'bn' ? 'একটি ত্রুটি হয়েছে। আবার চেষ্টা করুন।' : 'An error occurred. Please try again.'}
        </p>
      )}
    </form>
  );
};

export const ContentRenderer: React.FC<{ section: SectionContent }> = ({ section }) => {
  const { language } = useLanguage();

  if (section.type === 'text') {
    return <LanguageBlock content={section.content as MultiLangText} className="text-lg md:text-xl leading-relaxed opacity-90" />;
  }

  if (section.type === 'list') {
    const listItems = section.content as MultiLangText[];
    return (
      <div className="grid sm:grid-cols-2 gap-8">
        {listItems.map((item, idx) => (
          <div key={idx} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
             <div className="w-10 h-10 bg-[#76bc21]/10 rounded-xl flex items-center justify-center text-[#76bc21] font-bold mb-4">
               {idx + 1}
             </div>
             <LanguageBlock content={item} className="font-bold text-slate-800" />
          </div>
        ))}
      </div>
    );
  }

  if (section.type === 'steps') {
    const steps = section.content as MultiLangText[];
    return (
      <div className="relative">
        <div className={`absolute ${language === 'ar' ? 'right-4' : 'left-4'} top-0 bottom-0 w-1 bg-gradient-to-b from-[#76bc21] via-slate-200 to-transparent hidden md:block`}></div>
        <div className="space-y-12 md:space-y-20">
          {steps.map((step, idx) => (
            <div key={idx} className={`relative ${language === 'ar' ? 'md:pr-20' : 'md:pl-20'} group`}>
              <div className={`absolute ${language === 'ar' ? 'right-0' : 'left-0'} top-0 w-10 h-10 bg-white border-4 border-[#76bc21] text-[#00334e] flex items-center justify-center font-black text-sm rounded-full hidden md:flex z-10 shadow-lg transition-transform group-hover:scale-110`}>
                {idx + 1}
              </div>
              <div className="md:hidden mb-4">
                <span className="inline-flex items-center justify-center w-8 h-8 bg-[#00334e] text-white text-[12px] font-black rounded-xl">
                  {idx + 1}
                </span>
              </div>
              <LanguageBlock content={step} className="md:pt-1 text-slate-700" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (section.type === 'faq' && section.faqs) {
    return <FAQ faqs={section.faqs} />;
  }

  if (section.type === 'form') {
    return <ContactForm />;
  }

  return null;
};
