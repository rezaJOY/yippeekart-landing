
import React, { useEffect } from 'react';
import { useLocation, Outlet } from 'react-router-dom';
import Navigation from './Navigation';
import Footer from './Footer';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as any });
  }, [pathname]);
  return null;
};

const Layout: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col selection:bg-emerald-100 selection:text-[#00334e] bg-[#fcfcfc]">
      <ScrollToTop />
      <Navigation />
      <main id="main-content" className="flex-grow pt-16 sm:pt-24 outline-none">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
};

export default Layout;
