
export type Language = 'en' | 'ar' | 'bn';

export interface MultiLangText {
  en: string;
  ar: string;
  bn: string;
}

export interface SEOData {
  title: string;
  description: string;
  keywords: string[];
}

export interface StatItem {
  label: MultiLangText;
  value: string;
}

export interface HeroContent {
  title: MultiLangText;
  subtitle: MultiLangText;
  stats: StatItem[];
}

export interface FAQItem {
  question: MultiLangText;
  answer: MultiLangText;
}

export interface SectionContent {
  id: string;
  heading: MultiLangText;
  content?: MultiLangText | MultiLangText[];
  faqs?: FAQItem[];
  type: 'text' | 'list' | 'steps' | 'grid' | 'faq' | 'form';
}

export interface PageContent {
  seo: SEOData;
  hero?: HeroContent;
  sections: SectionContent[];
}

export interface NavLink {
  name: MultiLangText;
  path: string;
}

export interface ThemeColors {
  primary: string;
  secondary: string;
  accent: string;
}
