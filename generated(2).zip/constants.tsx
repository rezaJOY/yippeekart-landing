
import { PageContent, NavLink, MultiLangText } from './types';

export const NAV_LINKS: NavLink[] = [
  { name: { en: 'Home', ar: 'الرئيسية', bn: 'হোম' }, path: '/' },
  { name: { en: 'About Us', ar: 'من نحن', bn: 'আমাদের সম্পর্কে' }, path: '/about-us' },
  { name: { en: 'Services', ar: 'الخدمات', bn: 'সেবা সমূহ' }, path: '/manpower-categories' },
  { name: { en: 'Process', ar: 'إجراءات التوظيف', bn: 'نিয়োগ প্রক্রিয়া' }, path: '/recruitment-process' },
  { name: { en: 'Compliance', ar: 'الامتثال', bn: 'কমপ্লায়েন্স' }, path: '/compliance-licensing' },
  { name: { en: 'Saudi Focus', ar: 'التركيز السعودي', bn: 'সৌদি ফोकাস' }, path: '/saudi-arabia-manpower' },
  { name: { en: 'Contact', ar: 'اتصل بنا', bn: 'যোগাযোগ' }, path: '/contact' },
];

export const UI_LABELS: Record<string, MultiLangText> = {
  footer_desc: {
    en: "Government-Licensed Manpower Agency (Dhaka, Bangladesh). Specialized in large-scale human resource mobilization for Saudi Arabian industrial and facility management sectors.",
    ar: "وكالة استقدام عمالة مرخصة حكومياً (دكا، بنغلاديش). متخصصون في تعبئة الموارد البشرية واسعة النطاق لقطاعات الصناعة وإدارة المرافق السعودية.",
    bn: "সরকারি লাইসেন্সপ্রাপ্ত জনশক্তি সংস্থা (ঢাকা, বাংলাদেশ)। সৌদি আরবের শিল্প ও সুবিধা ব্যবস্থাপনা খাতের জন্য বড় আকারের মানবসম্পদ সংগ্রহের ক্ষেত্রে বিশেষায়িত।"
  },
  compliance_title: {
    en: "Compliance & Ethical Standards",
    ar: "معايير الامتثال والأخلاقيات",
    bn: "কমপ্লায়েন্স এবং নৈতিক মান"
  },
  contact_title: {
    en: "Institutional Contact",
    ar: "الاتصال المؤسسي",
    bn: "প্রাতিষ্ঠানিক যোগাযোগ"
  },
  rights_reserved: {
    en: "All rights reserved",
    ar: "جميع الحقوق محفوظة",
    bn: "সর্বস্বত্ব সংরক্ষিত"
  },
  form_name: { en: "Full Name", ar: "الاسم الكامل", bn: "পুরো নাম" },
  form_email: { en: "Email Address", ar: "البريد الإلكتروني", bn: "ইমেইল ঠিকানা" },
  form_phone: { en: "Phone Number", ar: "رقم الهاتف", bn: "ফোন নম্বর" },
  form_message: { en: "Message", ar: "رسالة", bn: "বার্তা" },
  form_submit: { en: "Send Message", ar: "إرسال الرسالة", bn: "বার্তা পাঠান" },
  form_success: { en: "Thank you! Your message has been sent.", ar: "شكراً لك! لقد تم إرسال رسالتك.", bn: "ধন্যবাদ! আপনার বার্তা পাঠানো হয়েছে।" }
};

export const PAGES: Record<string, PageContent> = {
  home: {
    seo: {
      title: "Ripon Enterprise | BMET Licensed Manpower Agency Bangladesh",
      description: "Government-licensed manpower recruitment agency in Bangladesh supplying unskilled workers to Saudi Arabia through approved and ethical processes.",
      keywords: ["BMET licensed manpower agency Bangladesh", "Saudi Arabia manpower recruitment"]
    },
    hero: {
      title: {
        en: "Ripon Enterprise",
        ar: "مؤسسة ريبون للمشاريع",
        bn: "রিপন এন্টারপ্রাইজ"
      },
      subtitle: {
        en: "Government-Licensed Manpower Recruitment Agency (RL-XXXX). Specialized in providing ethical labor solutions for the Kingdom of Saudi Arabia.",
        ar: "وكالة استقدام عمالة مرخصة حكومياً. متخصصون في تقديم حلول العمالة الأخلاقية للمملكة العربية السعودية.",
        bn: "সরকারি লাইসেন্সপ্রাপ্ত জনশক্তি নিয়োগকারী সংস্থা। সৌদি আরবের জন্য নৈতিক জনশক্তি সমাধান প্রদানে বিশেষায়িত।"
      },
      stats: [
        { 
          label: { en: "Years Experience", ar: "سنوات خبرة", bn: "বছরের অভিজ্ঞতা" }, 
          value: "20+" 
        },
        { 
          label: { en: "Saudi Partners", ar: "شركاء سعوديين", bn: "সৌদি পার্টনার" }, 
          value: "50+" 
        },
        { 
          label: { en: "Workers Deployed", ar: "عامل تم توظيفهم", bn: "নিযুক্ত কর্মী" }, 
          value: "15k+" 
        }
      ]
    },
    sections: [
      {
        id: "intro",
        heading: { en: "Institutional Overview", ar: "نظرة عامة مؤسسية", bn: "প্রতিষ্ঠানিক সংক্ষিপ্ত বিবরণ" },
        content: {
          en: "Ripon Enterprise stands as a cornerstone of compliance and ethical recruitment in Dhaka. With over two decades of experience, we bridge the gap between skilled labor from Bangladesh and the institutional needs of the Saudi Arabian corporate sector.",
          ar: "تقف مؤسسة ريبون للمشاريع كركن أساسي للامتثال والتوظيف الأخلاقي في دكا. مع أكثر من عقدين من الخبرة، نعمل على سد الفجوة بين العمالة من بنغلاديش والاحتياجات المؤسسية لقطاع الشركات في المملكة العربية السعودية.",
          bn: "রিপন এন্টারপ্রাইজ ঢাকায় কমপ্লায়েন্স এবং নৈতিক নিয়োগের অন্যতম ভিত্তি। দুই দশকেরও বেশি অভিজ্ঞতার সাথে, আমরা বাংলাদেশের শ্রমিক এবং সৌদি আরবের কর্পোরেট সেক্টরের প্রাতিষ্ঠানিক চাহিদার মধ্যে সেতুবন্ধন হিসেবে কাজ করি।"
        },
        type: 'text'
      },
      {
        id: "home-faq",
        heading: { en: "Frequently Asked Questions", ar: "الأسئلة الشائعة", bn: "সচরাচর জিজ্ঞাস্য প্রশ্নাবলী" },
        type: 'faq',
        faqs: [
          {
            question: { en: "What is your BMET License Number?", ar: "ما هو رقم ترخيص BMET الخاص بكم؟", bn: "আপনাদের বিএমইটি লাইসেন্স নম্বর কত?" },
            answer: { en: "Our official license number is RL-XXXX, fully authorized by the Bureau of Manpower, Employment and Training (BMET).", ar: "رقم ترخيصنا الرسمي هو RL-XXXX، وهو مفوض بالكامل من قبل مكتب القوى العاملة والتوظيف والتدريب (BMET).", bn: "আমাদের অফিসিয়াল লাইসেন্স নম্বর হলো RL-XXXX, যা বিএমইটি দ্বারা অনুমোদিত।" }
          },
          {
            question: { en: "Which regions in Saudi Arabia do you supply workers to?", ar: "ما هي المناطق في السعودية التي تزودونها بالعمالة؟", bn: "সৌদি আরবের কোন অঞ্চলগুলোতে আপনারা কর্মী সরবরাহ করেন?" },
            answer: { en: "We serve key industrial hubs including Riyadh, Jeddah, Dammam, and NEOM, partnering with top facility management firms.", ar: "نحن نخدم المراكز الصناعية الرئيسية بما في ذلك الرياض وجدة والدمام ونيوم، بالشراكة مع كبرى شركات إدارة المرافق.", bn: "আমরা রিয়াদ, জেদ্দা, দাম্মাম এবং নিওম সহ প্রধান শিল্প কেন্দ্রগুলিতে কাজ করি।" }
          },
          {
            question: { en: "What is your recruitment fee policy?", ar: "ما هي سياسة رسوم التوظيف لديكم؟", bn: "আপনাদের নিয়োগ ফি সংক্রান্ত নীতিমালা কী?" },
            answer: { en: "Ripon Enterprise strictly follows ethical recruitment guidelines, ensuring transparency and zero hidden costs for candidates.", ar: "تلتزم مؤسسة ريبون بصرامة بإرشادات التوظيف الأخلاقية، مما يضمن الشفافية وعدم وجود تكاليف مخفية للمرشحين.", bn: "রিপন এন্টারপ্রাইজ কঠোরভাবে নৈতিক নিয়োগ নির্দেশিকা অনুসরণ করে, যা প্রার্থীদের জন্য স্বচ্ছতা এবং কোনো লুকানো খরচ না থাকা নিশ্চিত করে।" }
          }
        ]
      }
    ]
  },
  about: {
    seo: {
      title: "About Us | Ripon Enterprise",
      description: "Learn about Ripon Enterprise's history and mission in manpower recruitment.",
      keywords: ["About Ripon Enterprise", "Bangladesh recruitment agency"]
    },
    sections: [
      {
        id: "background",
        heading: { en: "Company Background", ar: "خلفية الشركة", bn: "কোম্পানির পটভূমি" },
        content: {
          en: "Founded on the principles of integrity and government compliance, Ripon Enterprise has served as a reliable partner for human resource mobilization. Our deep-rooted understanding of both Bangladesh labor laws and Saudi Arabian labor regulations ensures a seamless transition for every deployment.",
          ar: "تأسست مؤسسة ريبون للمشاريع على مبادئ النزاهة والامتثال الحكومي، وعملت كشريك موثوق لتعبئة الموارد البشرية. يضمن فهمنا العميق لقوانين العمل في بنغلاديش وأنظمة العمل السعودية انتقالاً لسلاً لكل عملية توظيف.",
          bn: "সততা এবং সরকারি কমপ্লায়েন্সের নীতির ওপর ভিত্তি করে প্রতিষ্ঠিত রিপন এন্টারপ্রাইজ মানবসম্পদ সচল করার ক্ষেত্রে একটি নির্ভরযোগ্য অংশীদার হিসেবে কাজ করছে। বাংলাদেশ শ্রম আইন এবং সৌদি আরবের শ্রম বিধিমালা উভয় সম্পর্কে আমাদের গভীর জ্ঞান প্রতিটি কর্মসংস্থান প্রক্রিয়ার সুশৃঙ্খল সমাপ্তি নিশ্চিত করে।"
        },
        type: 'text'
      }
    ]
  },
  services: {
    seo: {
      title: "Manpower Categories | Ripon Enterprise",
      description: "Explore the labor categories we supply to Saudi Arabia.",
      keywords: ["Labor categories", "Saudi manpower"]
    },
    sections: [
      {
        id: "categories",
        heading: { en: "Manpower Categories", ar: "فئات العمالة", bn: "জনশক্তি বিভাগসমূহ" },
        content: [
          { en: "General Cleaning Staff", ar: "موظفي التنظيف العام", bn: "সাধারণ পরিচ্ছন্নতা কর্মী" },
          { en: "Loading and Unloading Labor", ar: "عمال التحميل والتفريغ", bn: "লোডিং এবং আনলোডিং কর্মী" },
          { en: "Construction Workers", ar: "عمال البناء", bn: "নির্মাণ কর্মী" }
        ],
        type: 'list'
      }
    ]
  },
  process: {
    seo: {
      title: "Recruitment Process | Ripon Enterprise",
      description: "Step-by-step recruitment procedure from Bangladesh to Saudi Arabia.",
      keywords: ["Recruitment steps", "Manpower workflow"]
    },
    sections: [
      {
        id: "steps",
        heading: { en: "Recruitment Workflow", ar: "سير عمل التوظيف", bn: "নিয়োগ কর্মপ্রবাহ" },
        content: [
          { en: "Demand Letter Verification", ar: "التحقق من خطاب الطلب", bn: "চাহিদাপত্র যাচাইকরণ" },
          { en: "Medical Examination", ar: "الفحص الطبي", bn: "চিকিৎসা পরীক্ষা" },
          { en: "Visa Processing", ar: "معالجة التأشيرة", bn: "ভিসা প্রসেসিং" }
        ],
        type: 'steps'
      }
    ]
  },
  compliance: {
    seo: {
      title: "Compliance & Licensing | Ripon Enterprise",
      description: "Our government licenses and ethical standards.",
      keywords: ["BMET license", "RL number"]
    },
    sections: [
      {
        id: "licensing",
        heading: { en: "Regulatory Compliance", ar: "الامتثال التنظيمي", bn: "নিয়ন্ত্রক কমপ্লায়েন্স" },
        content: {
          en: "We strictly adhere to BMET and Saudi labor laws.",
          ar: "نحن نلتزم بصرامة بقوانين العمل في بنغلاديش والسعودية.",
          bn: "আমরা বিএমইটি এবং সৌদি শ্রম আইন কঠোরভাবে মেনে চলি।"
        },
        type: 'text'
      }
    ]
  },
  saudi: {
    seo: {
      title: "Saudi Arabia Focus | Ripon Enterprise",
      description: "Our expertise in the Saudi Arabian labor market.",
      keywords: ["Saudi labor market", "Jeddah recruitment"]
    },
    sections: [
      {
        id: "focus",
        heading: { en: "Saudi Market Expertise", ar: "الخبرة في السوق السعودي", bn: "সৌদি বাজারের দক্ষতা" },
        content: {
          en: "Unrivaled expertise in navigating the Kingdom's professional requirements.",
          ar: "خبرة لا تضاهى في التعامل مع المتطلبات المهنية للمملكة.",
          bn: "সৌদি আরবের পেশাদার চাহিদা পূরণে আমাদের অতুলনীয় দক্ষতা রয়েছে।"
        },
        type: 'text'
      }
    ]
  },
  contact: {
    seo: {
      title: "Contact Us | Ripon Enterprise",
      description: "Get in touch with our head office in Dhaka.",
      keywords: ["Contact Ripon Enterprise", "Recruitment agency contact"]
    },
    sections: [
      {
        id: "contact-info",
        heading: { en: "Contact Details", ar: "تفاصيل الاتصال", bn: "যোগাযোগের বিবরণ" },
        content: [
          { en: "Email: corporate@riponenterprise.com", ar: "البريد الإلكتروني: corporate@riponenterprise.com", bn: "ইমেইল: corporate@riponenterprise.com" },
          { en: "Address: Dhaka, Bangladesh", ar: "العنوان: دكا، بنغلاديش", bn: "ঠিকানা: ঢাকা, বাংলাদেশ" }
        ],
        type: 'list'
      },
      {
        id: "contact-form",
        heading: { en: "Send an Inquiry", ar: "أرسل استفسارك", bn: "একটি অনুসন্ধান পাঠান" },
        type: 'form'
      }
    ]
  }
};
