
import React from 'react';
import { createMemoryRouter, RouterProvider, Navigate } from 'react-router-dom';
import { LanguageProvider } from './LanguageContext';
import Layout from './components/Layout';
import PageTemplate from './pages/PageTemplate';

/**
 * createMemoryRouter is utilized to circumvent security policy denials 
 * (Location.assign access denied) typical in restricted 'blob:' origin sandboxes.
 * This keeps the application history stack internal to React state, 
 * ensuring seamless navigation within the preview environment.
 */
const router = createMemoryRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        index: true,
        element: <PageTemplate pageKey="home" />
      },
      {
        path: "about-us",
        element: <PageTemplate pageKey="about" />
      },
      {
        path: "manpower-categories",
        element: <PageTemplate pageKey="services" />
      },
      {
        path: "recruitment-process",
        element: <PageTemplate pageKey="process" />
      },
      {
        path: "compliance-licensing",
        element: <PageTemplate pageKey="compliance" />
      },
      {
        path: "saudi-arabia-manpower",
        element: <PageTemplate pageKey="saudi" />
      },
      {
        path: "contact",
        element: <PageTemplate pageKey="contact" />
      },
      {
        path: "*",
        element: <Navigate to="/" replace />
      }
    ]
  }
], {
  initialEntries: ['/'],
});

export default function App() {
  return (
    <LanguageProvider>
      <RouterProvider router={router} />
    </LanguageProvider>
  );
}
